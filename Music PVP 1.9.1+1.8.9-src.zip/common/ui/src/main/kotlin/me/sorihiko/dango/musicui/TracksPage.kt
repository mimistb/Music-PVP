package me.sorihiko.dango.musicui

import me.sorihiko.dango.DangoClient
import me.sorihiko.dango.music.CoverCache
import me.sorihiko.dango.music.LocalLibrary
import me.sorihiko.dango.music.MusicPlayer
import me.sorihiko.dango.music.MusicScreen
import me.sorihiko.dango.music.NeteaseApi
import me.sorihiko.dango.music.NeteasePlaylist
import me.sorihiko.dango.music.NeteaseTrack
import me.sorihiko.dango.platform.Keys
import me.sorihiko.dango.ui.LayoutBounds
import me.sorihiko.dango.ui.ShapeStyle
import me.sorihiko.dango.ui.Theme
import me.sorihiko.dango.utils.Color

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * 歌曲列表页（歌单详情、搜索结果、播放队列）：
 *   标题区：返回、歌单封面、播放全部、筛选框、定位、列表 / 封面墙切换
 *   内容：列表（序号 / 小封面 / 歌名 / 歌手 / 时长 + 右侧滚动条），或封面墙（Coverflow）
 */
internal class TracksPage(private val screen: MusicScreen) {
    private val ui = screen.ui

    /** 本帧画了歌曲列表的区域（滚轮用），没画就是空的 */
    var area = LayoutBounds()

    // 歌单内筛选：输入状态交给共用的 TextInput（Ctrl+C / V / X / A 全支持）
    private val filter = TextInput(60)
    val filterText: String get() = filter.text
    var filterFocused = false
    var filterRect = LayoutBounds()
        private set
    private var filterCacheSrc: List<NeteaseTrack>? = null
    private var filterCacheKey = ""
    private var filterCache: List<Pair<Int, NeteaseTrack>> = emptyList()

    // 列表滚动：目标（行）和平滑后的当前位置；一屏放得下几行（关掉界面再打开从上次的位置继续）
    private var scroll = ScreenState.tracksScroll
    private var listPos = scroll.toFloat()
    var listRows = 10
        private set

    // 右侧滚动条
    private var sbTrack = LayoutBounds()
    private var sbTotal = 0
    var sbDragging = false
        private set
    private var sbGrab = 0f

    // "定位"后那一行闪一下
    private var flashId = 0L
    private var flashAt = 0L

    // 封面墙：目标下标和平滑后的当前位置
    private var cfTarget = ScreenState.tracksCover
    private var cfPos = cfTarget.toFloat()

    private val tracksPage: Boolean
        get() = ScreenState.page.let {
            it == Page.PLAYLIST || it == Page.SEARCH || it == Page.QUEUE || it == Page.LOCAL ||
                it == Page.DAILY || it == Page.FREE
        }

    // ---------------------------------------------------------------- 每帧 / 切页

    fun tick() {
        cfPos = ui.approach(cfPos, cfTarget.toFloat(), 90f)
        if (abs(cfTarget - cfPos) < 0.001f) cfPos = cfTarget.toFloat()
        // 滚轮 / 快捷键改的位置先记进 ScreenState，关掉界面再打开就能回到原地
        val scrollNow = scroll
        ScreenState.tracksScroll = scrollNow
        ScreenState.tracksCover = cfTarget
    }

    fun beginFrame() {
        if (!sbDragging) sbTotal = 0   // 没画歌单列表的页面上不响应滚动条
    }

    /** 换了页面：列表直接从当前滚动位置开始画，不从别处滑过来 */
    fun onPageChanged() {
        listPos = scroll.toFloat()
    }

    fun resetScroll() {
        scroll = 0
        ScreenState.tracksScroll = 0
    }

    fun resetCoverflow() {
        cfTarget = 0
        cfPos = 0f
        ScreenState.tracksCover = 0
    }

    fun scroll(wheel: Int, rows: Int) {
        if (ScreenState.coverView) cfTarget += if (wheel > 0) -1 else 1 else scroll += rows
    }

    // ---------------------------------------------------------------- 数据

    fun currentTracks(): Pair<String, List<NeteaseTrack>?> = when (ScreenState.page) {
        Page.SEARCH -> "\"${ScreenState.lastQuery}\"" to Library.searchResults
        Page.QUEUE -> "正在播放" to MusicPlayer.queue
        Page.LOCAL -> "本地音乐" to LocalLibrary.tracks
        Page.DAILY -> "每日推荐" to Library.daily
        Page.FREE -> "免费听" to Library.free
        Page.PLAYLIST -> {
            val p = ScreenState.opened
            (p?.name ?: "") to (if (p != null) Library.tracks(p.id) else null)
        }
        else -> "" to null
    }

    private fun norm(s: String) = s.lowercase().replace(" ", "")

    /** 当前页显示的歌（筛选后），带原来的序号；结果缓存起来，两千多首也不卡 */
    private fun shown(all: List<NeteaseTrack>): List<Pair<Int, NeteaseTrack>> {
        val key = norm(filterText)
        if (all === filterCacheSrc && key == filterCacheKey) return filterCache
        filterCacheSrc = all
        filterCacheKey = key
        filterCache = if (key.isEmpty()) {
            all.mapIndexed { i, t -> i to t }
        } else {
            all.mapIndexedNotNull { i, t ->
                if (norm(t.name).contains(key) || t.artists.any { norm(it).contains(key) }) i to t else null
            }
        }
        return filterCache
    }

    fun clearFilter() {
        filter.clear()
        filterFocused = false
    }

    /** 搜索结果的介绍统计：共几首，其中免费 / VIP / 付费各有多少 */
    private fun searchSummary(all: List<NeteaseTrack>): String {
        val free = all.count { it.fee == 0 || it.fee == 8 }
        val vip = all.count { it.fee == 1 || it.fee == 4 }
        return buildString {
            append("${all.size} 首")
            if (free > 0) append(" · 免费 $free 首")
            if (vip > 0) append(" · VIP/付费 $vip 首")
            if (free == 0 && vip == 0) append(" · 收费信息未知")
        }
    }

    /** 播放：队列始终是完整歌单（筛选只影响显示），从点的那首开始 */
    private fun playFrom(all: List<NeteaseTrack>, index: Int) {
        if (ScreenState.page == Page.QUEUE) MusicPlayer.playIndex(index) else MusicPlayer.playQueue(all, index)
    }

    /** 跳到正在播放的那首：列表滚到它居中，封面墙转到它，并闪一下 */
    private fun locateCurrent() {
        val all = currentTracks().second ?: return
        val cur = MusicPlayer.current ?: return
        var list = shown(all)
        var idx = list.indexOfFirst { it.second.id == cur.id }
        if (idx < 0 && filterText.isNotEmpty()) {
            // 被筛选掉了：清掉筛选再找
            clearFilter()
            list = shown(all)
            idx = list.indexOfFirst { it.second.id == cur.id }
        }
        if (idx < 0) return
        scroll = (idx - listRows / 2).coerceAtLeast(0)
        cfTarget = idx
        cfPos = idx.toFloat()
        flashId = cur.id
        flashAt = System.currentTimeMillis()
    }

    private fun currentInList(): Boolean {
        val cur = MusicPlayer.current ?: return false
        return currentTracks().second?.any { it.id == cur.id } == true
    }

    /** 封面墙转到正在播放的那首（没有就第一首） */
    fun focusCurrentInCoverflow() {
        val tracks = currentTracks().second?.let { shown(it) } ?: return
        val cur = MusicPlayer.current
        val idx = if (cur != null) tracks.indexOfFirst { it.second.id == cur.id } else -1
        cfTarget = if (idx >= 0) idx else 0
        cfPos = cfTarget.toFloat()
    }

    // ---------------------------------------------------------------- 绘制

    fun draw(page: LayoutBounds) {
        val (title, tracks) = currentTracks()
        val y = page.y
        var headerH = 62f
        ui.headerAnim { headerH = drawHeader(page, title, tracks) }
        area = LayoutBounds(page.x, y + headerH, page.width, page.bottom - (y + headerH))
        if (tracks == null) {
            // 歌单读取失败 / 还没读完：空闲且过了冷却时间就自动再读一次
            if (ScreenState.page == Page.PLAYLIST) ScreenState.opened?.let { Library.ensureTracks(it.id) }
            // 每日推荐 / 免费听还没读完：给个提示，别让页面空着
            when (ScreenState.page) {
                Page.DAILY -> ui.text(if (!NeteaseApi.loggedIn) "登录后查看每日推荐" else "加载中…",
                    area.x + 12f, area.y + 20f, 12f, Theme.TEXT_TERTIARY)
                Page.FREE -> ui.text("加载中…", area.x + 12f, area.y + 20f, 12f, Theme.TEXT_TERTIARY)
                else -> {}
            }
            return
        }
        // 搜索结果：相关歌单和歌曲一起显示（歌单横排在歌曲列表上面）
        var body = area
        if (ScreenState.page == Page.SEARCH && Library.searchPlaylists.isNotEmpty()) {
            val rowH = drawPlaylistRow(area, Library.searchPlaylists)
            body = LayoutBounds(area.x, area.y + rowH, area.width, (area.height - rowH).coerceAtLeast(0f))
        }
        area = body
        val list = shown(tracks)
        if (list.isEmpty() && filterText.isNotEmpty()) {
            ui.text("没有匹配「$filterText」的歌曲", body.x + 12f, body.y + 20f, 12f, Theme.TEXT_TERTIARY)
            return
        }
        if (list.isEmpty() && ScreenState.page == Page.LOCAL) {
            val msg = if (LocalLibrary.scanning) "正在扫描本地音乐…"
            else "把 mp3 / wav 放进 config/dangomusic/music，再点右上角「刷新」"
            ui.text(msg, body.x + 12f, body.y + 20f, 12f, Theme.TEXT_TERTIARY)
            return
        }
        if (list.isEmpty() && ScreenState.page == Page.DAILY) {
            ui.text(if (!NeteaseApi.loggedIn) "登录后查看每日推荐" else "今日推荐还没有内容",
                body.x + 12f, body.y + 20f, 12f, Theme.TEXT_TERTIARY)
            return
        }
        if (list.isEmpty() && ScreenState.page == Page.FREE) {
            ui.text("暂时没有免费新歌", body.x + 12f, body.y + 20f, 12f, Theme.TEXT_TERTIARY)
            return
        }
        if (ScreenState.coverView) ui.itemAnim(0) { drawCoverflow(body, tracks, list) } else drawTrackList(body, tracks, list)
    }

    /** 搜索结果顶部的相关歌单横排（封面 + 名字），返回占用的高度 */
    private fun drawPlaylistRow(area: LayoutBounds, playlists: List<NeteasePlaylist>): Float {
        val ctx = ui.ctx
        val rowH = 118f
        ui.text("相关歌单", area.x, area.y, 10f, Theme.TEXT_TERTIARY, Theme.FONT_SEMIBOLD)
        val top = area.y + 16f
        val cellW = 96f
        val gap = 10f
        val maxN = ((area.width + gap) / (cellW + gap)).toInt().coerceIn(1, 6)
        // 裁剪区要覆盖到“N 首”那行，否则最后一行会被裁掉
        val clip = LayoutBounds(area.x, top - 4f, area.width, rowH - 12f)
        ui.beginClip(clip)
        for (i in 0 until min(maxN, playlists.size)) {
            val p = playlists[i]
            val x = area.x + i * (cellW + gap)
            val cover = LayoutBounds(x, top, 72f, 72f)
            val cell = LayoutBounds(x, top - 4f, cellW - 4f, rowH - 12f)
            if (ui.hover(cell)) ctx.drawShape(cell, ShapeStyle(Theme.CARD_HOVER, 8f))
            ui.drawCover(cover, CoverCache.playlist(p), 10f)
            ui.text(ui.trim(p.name, cellW - 4f, 10f, Theme.FONT_MEDIUM), x, cover.bottom + 6f, 10f,
                Theme.TEXT_PRIMARY, Theme.FONT_MEDIUM)
            ui.text("${p.trackCount} 首", x, cover.bottom + 20f, 9f, Theme.TEXT_TERTIARY)
            ui.hits += cell.intersect(clip) to { screen.openPlaylist(p, Page.SEARCH) }
        }
        ui.endClip()
        return rowH
    }

    /** 标题区，返回它的高度 */
    private fun drawHeader(page: LayoutBounds, title: String, tracks: List<NeteaseTrack>?): Float {
        val ctx = ui.ctx
        val state = ScreenState
        var x = page.x
        val y = page.y
        var headerH = 62f

        // 返回
        if (state.backPage != null) {
            val bb = LayoutBounds(x, y + 2f, 28f, 28f)
            ctx.drawShape(bb, ShapeStyle(if (ui.hover(bb)) Theme.CARD_HOVER else Theme.CARD, 14f))
            ui.icon("◀", bb.x + 13.5f, bb.y + 14f, 10f, Theme.TEXT_PRIMARY)
            ui.hits += bb to { screen.goBack() }
            x += 40f
        }

        // 歌单封面
        val p = state.opened
        if (state.page == Page.PLAYLIST && p != null) {
            val cv = LayoutBounds(x, y, 96f, 96f)
            ui.drawCover(cv, CoverCache.playlist(p), 12f)
            x = cv.right + 18f
            headerH = 112f
        }

        val header = when (state.page) {
            Page.SEARCH -> "搜索「${state.lastQuery}」"
            Page.QUEUE -> "正在播放"
            else -> title
        }
        val segW = 132f
        ui.text(ui.trim(header, page.right - segW - 24f - x, 22f, Theme.FONT_DISPLAY), x, y + 4f, 22f, Theme.TEXT_PRIMARY, Theme.FONT_DISPLAY)
        val sub = when {
            state.page == Page.SEARCH && Library.searching -> "搜索中…"
            state.page == Page.SEARCH && tracks.isNullOrEmpty() ->
                if (NeteaseApi.lastSearchError.isNotEmpty()) "搜索失败：" + NeteaseApi.lastSearchError else "无结果"
            state.page == Page.QUEUE && tracks.isNullOrEmpty() -> "播放队列为空"
            tracks == null -> "加载中…"
            state.page == Page.SEARCH -> searchSummary(tracks)
            filterText.isNotEmpty() -> "${shown(tracks).size} / ${tracks.size} 首"
            else -> "${tracks.size} 首歌"
        }
        ui.text(sub, x, y + 34f, 11f, Theme.TEXT_SECONDARY, Theme.FONT_SEMIBOLD)

        // 播放全部
        if (!tracks.isNullOrEmpty() && state.page != Page.QUEUE) {
            val label = "播放全部"
            val pb = LayoutBounds(x, y + (if (headerH > 100f) 64f else 52f) - 6f, ui.width(label, 12f, Theme.FONT_SEMIBOLD) + 44f, 30f)
            ctx.drawShape(pb, ShapeStyle(if (ui.hover(pb)) RED.copy(a = 0.85f) else RED, 15f))
            ui.icon("▶", pb.x + 17f, pb.y + 15f, 11f, Theme.TEXT_PRIMARY)
            ui.text(label, pb.x + 30f, pb.y + 9f, 12f, Theme.TEXT_PRIMARY, Theme.FONT_SEMIBOLD)
            ui.hits += pb to { MusicPlayer.playQueue(tracks, if (MusicPlayer.shuffle) (tracks.indices).random() else 0) }
            if (headerH < 100f) headerH = 92f
        }

        // 右上角：列表 / 封面墙
        val seg = LayoutBounds(page.right - segW, y + 4f, segW, 26f)
        ui.card(seg, Theme.CARD, 13f)
        val half = LayoutBounds(seg.x, seg.y, segW / 2f, seg.height)
        val other = LayoutBounds(seg.x + segW / 2f, seg.y, segW / 2f, seg.height)
        val coverView = state.coverView
        ctx.drawGlass(if (coverView) other else half, Theme.GLASS_SELECTION)
        ui.text("列表", half.x + (half.width - ui.width("列表", 12f, Theme.FONT_MEDIUM)) / 2f, half.y + 8f, 12f,
            if (coverView) Theme.TEXT_SECONDARY else Theme.TEXT_PRIMARY, Theme.FONT_MEDIUM)
        ui.text("封面", other.x + (other.width - ui.width("封面", 12f, Theme.FONT_MEDIUM)) / 2f, other.y + 8f, 12f,
            if (coverView) Theme.TEXT_PRIMARY else Theme.TEXT_SECONDARY, Theme.FONT_MEDIUM)
        ui.hits += half to { if (ScreenState.coverView) screen.toggleCoverView() }
        ui.hits += other to { if (!ScreenState.coverView) screen.toggleCoverView() }

        // 定位到正在播放（列表里有这首歌时才显示）
        var rightX = seg.x - 10f
        if (currentInList()) {
            val label = "定位"
            val lw = ui.width(label, 11f, Theme.FONT_MEDIUM) + 34f
            val lb = LayoutBounds(rightX - lw, y + 4f, lw, 26f)
            ui.card(lb, if (ui.hover(lb)) Theme.CARD_HOVER else Theme.CARD, 13f)
            ui.icon("◎", lb.x + 14f, lb.y + 13f, 11f, RED)
            ui.text(label, lb.x + 25f, lb.y + 8f, 11f, Theme.TEXT_PRIMARY, Theme.FONT_MEDIUM)
            ui.hits += lb to { locateCurrent() }
            rightX = lb.x - 10f
        }

        // 本地音乐：重新扫描目录
        if (state.page == Page.LOCAL) {
            val label = if (LocalLibrary.scanning) "扫描中" else "刷新"
            val lw = ui.width(label, 11f, Theme.FONT_MEDIUM) + 26f
            val rb = LayoutBounds(rightX - lw, y + 4f, lw, 26f)
            ui.card(rb, if (ui.hover(rb)) Theme.CARD_HOVER else Theme.CARD, 13f)
            ui.text(label, rb.x + (rb.width - ui.width(label, 11f, Theme.FONT_MEDIUM)) / 2f, rb.y + 8f, 11f,
                Theme.TEXT_PRIMARY, Theme.FONT_MEDIUM)
            ui.hits += rb to { LocalLibrary.scan() }
            rightX = rb.x - 10f
        }

        // 歌单内筛选框（按歌名 / 歌手，输入即筛选）
        if (tracks != null && state.page != Page.SEARCH) drawFilter(rightX, y) else filterRect = LayoutBounds()
        return headerH
    }

    private fun drawFilter(rightX: Float, y: Float) {
        val ctx = ui.ctx
        val fw = 190f
        filterRect = LayoutBounds(rightX - fw, y + 4f, fw, 26f)
        ui.card(filterRect, if (filterFocused) Theme.CARD_HOVER else Theme.CARD, 13f)
        if (filterFocused) ctx.drawShape(filterRect, ShapeStyle(Color(0f, 0f, 0f, 0f), 13f, 1f, RED))
        ctx.drawShape(LayoutBounds(filterRect.x + 10f, filterRect.y + 8f, 8f, 8f), ShapeStyle(Color(0f, 0f, 0f, 0f), 4f, 1.3f, Theme.TEXT_SECONDARY))
        ctx.drawShape(LayoutBounds(filterRect.x + 16.5f, filterRect.y + 15f, 4f, 1.5f), ShapeStyle(Theme.TEXT_SECONDARY, 0.75f))
        val placeholder = filterText.isEmpty() && !filterFocused
        val hint = if (ScreenState.page == Page.LOCAL) "在本地音乐内筛选…" else "在本歌单内筛选…"
        var shownText = if (placeholder) hint else filter.display(filterFocused && caretVisible())
        val maxW = filterRect.width - 30f - (if (filterText.isNotEmpty()) 18f else 0f)
        while (shownText.length > 1 && ui.width(shownText, 11f) > maxW) shownText = shownText.substring(1)
        ui.text(shownText, filterRect.x + 26f, filterRect.y + 8f, 11f, if (placeholder) Theme.TEXT_TERTIARY else Theme.TEXT_PRIMARY)
        ui.hits += filterRect to {
            filterFocused = true
            screen.sidebar.searchFocused = false
        }
        if (filterText.isNotEmpty()) {
            val xb = LayoutBounds(filterRect.right - 22f, filterRect.y + 4f, 18f, 18f)
            if (ui.hover(xb)) ctx.drawShape(xb, ShapeStyle(Theme.CARD_HOVER, 9f))
            ui.icon("×", xb.x + 9f, xb.y + 9f, 11f, Theme.TEXT_SECONDARY)
            ui.hits.add(0, xb to { clearFilter() })     // 优先于筛选框本身
        }
    }

    // ---------------------------------------------------------------- 列表 + 滚动条

    /** 滚动条滑块的位置和高度 */
    private fun thumbOf(track: LayoutBounds, total: Int, rows: Int): LayoutBounds {
        val h = max(28f, track.height * rows / total.coerceAtLeast(1))
        val maxScroll = max(1, total - rows)
        val pos = if (sbDragging) scroll.toFloat() else listPos
        val y = track.y + (track.height - h) * (pos / maxScroll).coerceIn(0f, 1f)
        return LayoutBounds(track.x, y, track.width, h)
    }

    /**
     * 歌单右边的滚动条：拖滑块快速滚动，点空白处直接跳过去；
     * 拖动时旁边显示现在在第几首。
     */
    private fun drawScrollbar(track: LayoutBounds, total: Int, rows: Int) {
        sbTrack = track
        sbTotal = total
        if (total <= rows) {
            sbTrack = LayoutBounds()
            return
        }
        val hot = sbDragging || track.expand(8f, 0f).contains(ui.mx, ui.my)
        ui.ctx.drawShape(track, ShapeStyle(Color(1f, 1f, 1f, if (hot) 0.10f else 0.05f), track.width / 2f))
        val th = thumbOf(track, total, rows)
        val thumb = if (hot) LayoutBounds(th.x - 1.5f, th.y, th.width + 3f, th.height) else th
        ui.ctx.drawShape(thumb, ShapeStyle(if (sbDragging) RED else Color(1f, 1f, 1f, if (hot) 0.55f else 0.30f), thumb.width / 2f))
        if (sbDragging) {
            val label = "${scroll + 1} / $total"
            val lw = ui.width(label, 11f, Theme.FONT_SEMIBOLD) + 18f
            val lb = LayoutBounds(track.x - lw - 10f, th.y + th.height / 2f - 12f, lw, 24f)
            ui.ctx.drawGlass(lb, Theme.GLASS_SELECTION)
            ui.text(label, lb.x + 9f, lb.y + 7f, 11f, Theme.TEXT_PRIMARY, Theme.FONT_SEMIBOLD)
        }
    }

    private fun scrollbarTo(y: Int) {
        val track = sbTrack
        val rows = listRows
        if (sbTotal <= rows || track.height <= 0f) return
        val th = thumbOf(track, sbTotal, rows)
        val frac = ((y - sbGrab) - track.y) / max(1f, track.height - th.height)
        scroll = (frac.coerceIn(0f, 1f) * (sbTotal - rows)).toInt()
    }

    /** 按在滚动条上：按在滑块上就拖，按在空白处就把滑块中心跳过去再拖。返回 true 表示按到了 */
    fun scrollbarDown(mx: Int, my: Int): Boolean {
        if (ScreenState.coverView || sbTotal <= listRows || sbTrack.height <= 0f || !sbTrack.expand(8f, 0f).contains(mx, my)) return false
        val th = thumbOf(sbTrack, sbTotal, listRows)
        sbGrab = if (my >= th.y && my <= th.bottom) my - th.y else th.height / 2f
        sbDragging = true
        scrollbarTo(my)
        return true
    }

    fun scrollbarDrag(y: Int) = scrollbarTo(y)

    fun scrollbarUp() {
        sbDragging = false
    }

    /** 列表：序号 / 小封面 / 歌名 / 歌手 / 时长 */
    private fun drawTrackList(list: LayoutBounds, all: List<NeteaseTrack>, tracks: List<Pair<Int, NeteaseTrack>>) {
        val ctx = ui.ctx
        // 表头
        ui.text("#", list.x + 12f, list.y, 10f, Theme.TEXT_TERTIARY, Theme.FONT_SEMIBOLD)
        ui.text("歌曲", list.x + 84f, list.y, 10f, Theme.TEXT_TERTIARY, Theme.FONT_SEMIBOLD)
        val sbW = 16f   // 右边留给滚动条
        ui.text("时长", list.right - sbW - 12f - ui.width("时长", 10f, Theme.FONT_SEMIBOLD), list.y, 10f, Theme.TEXT_TERTIARY, Theme.FONT_SEMIBOLD)
        ctx.drawShape(LayoutBounds(list.x, list.y + 16f, list.width - sbW, 1f), ShapeStyle(Theme.SEPARATOR))
        val body = LayoutBounds(list.x, list.y + 22f, list.width - sbW, list.height - 22f)

        val rowH = 44f
        val rows = max(1, (body.height / rowH).toInt())
        listRows = rows
        scroll = scroll.coerceIn(0, max(0, tracks.size - rows))
        listPos = if (sbDragging) scroll.toFloat() else ui.easeScroll(listPos, scroll, rows * 3)
        drawScrollbar(LayoutBounds(list.right - 9f, body.y + 2f, 5f, rows * rowH - 8f), tracks.size, rows)
        val flash = (1f - (System.currentTimeMillis() - flashAt) / 1400f).coerceIn(0f, 1f)
        val playing = MusicPlayer.current
        val first = kotlin.math.floor(listPos).toInt()
        val frac = listPos - first
        val clipArea = LayoutBounds(body.x - 4f, body.y - 2f, body.width + 8f, rows * rowH)
        ui.beginClip(clipArea)
        for (r in 0..rows) {
            val vi = first + r
            if (vi < 0) continue
            if (vi >= tracks.size) break
            val (i, t) = tracks[vi]
            ui.itemAnim(r) {
                val row = LayoutBounds(body.x, body.y + (r - frac) * rowH, body.width, rowH - 4f)
                val isCur = playing != null && playing.id == t.id
                when {
                    isCur -> ctx.drawGlass(row, Theme.GLASS_SELECTION)
                    ui.hover(row) -> ui.card(row, Theme.CARD_HOVER, 10f)
                }
                if (flash > 0f && t.id == flashId) {
                    ctx.drawShape(row, ShapeStyle(Color(0f, 0f, 0f, 0f), 10f, 1.5f, RED.copy(a = flash)))
                }
                if (isCur && MusicPlayer.state == MusicPlayer.State.PLAYING) {
                    ui.icon("♫", row.x + 18f, row.y + 20f, 12f, RED)
                } else {
                    ui.text("${i + 1}", row.x + 12f, row.y + 15f, 11f, Theme.TEXT_TERTIARY)
                }
                val thumb = LayoutBounds(row.x + 46f, row.y + 4f, row.height - 8f, row.height - 8f)
                ui.drawCover(thumb, CoverCache.track(t), 6f)
                val tx = thumb.right + 12f
                val durW = 44f
                val metaRight = row.right - durW - 12f
                val avail = metaRight - tx
                ui.text(ui.trim(t.name, avail, 13f), tx, row.y + 7f, 13f, if (isCur) RED else Theme.TEXT_PRIMARY)
                // 第二行：歌手 · 收费类型 · 热度（窄窗口下先保证歌手名有位置，放不下就不显示标签）
                val metaAvail = metaRight - tx
                val feeLabel = feeTag(t.fee).takeIf { metaAvail >= 110f }
                var popLabel = if (t.popularity > 0) "热度 ${t.popularity}" else null
                if (popLabel != null && metaAvail < 160f) popLabel = null
                var tailW = 0f
                if (feeLabel != null) tailW += ui.width(feeLabel, 10f, Theme.FONT_SEMIBOLD) + 6f
                if (popLabel != null) tailW += ui.width(popLabel, 10f) + 6f
                val artist = ui.trim(t.artists.joinToString(" / "), (metaRight - tx - tailW - 8f).coerceAtLeast(24f), 11f)
                ui.text(artist, tx, row.y + 23f, 11f, Theme.TEXT_SECONDARY)
                var mx = tx + ui.width(artist, 11f) + 8f
                if (feeLabel != null) {
                    ui.text(feeLabel, mx, row.y + 23f, 10f, feeColor(t.fee), Theme.FONT_SEMIBOLD)
                    mx += ui.width(feeLabel, 10f, Theme.FONT_SEMIBOLD) + 6f
                }
                if (popLabel != null) ui.text(popLabel, mx, row.y + 23f, 10f, Theme.TEXT_TERTIARY)
                val d = fmtTime(t.durationMs)
                ui.text(d, row.right - 12f - ui.width(d, 11f), row.y + 15f, 11f, Theme.TEXT_TERTIARY)
                ui.hits += row.intersect(clipArea) to { playFrom(all, i) }
            }
        }
        ui.endClip()
    }

    // ---------------------------------------------------------------- 封面墙（Coverflow）

    /**
     * 中间一张大封面，两边的依次变小、变淡、往后叠。
     * 滚轮 / ←→ / 点两侧切换，点中间那张（或回车）播放。
     */
    private fun drawCoverflow(area: LayoutBounds, all: List<NeteaseTrack>, shownList: List<Pair<Int, NeteaseTrack>>) {
        val tracks = shownList.map { it.second }
        if (tracks.isEmpty()) return
        cfTarget = cfTarget.coerceIn(0, tracks.size - 1)

        val size = min(area.height * 0.66f, 240f)
        val cx = area.x + area.width / 2f
        // 封面 + 下面三行字作为一个整体，在区域里竖直居中（稍微偏上一点点）
        val blockH = size + 66f
        val cy = area.y + max(8f, (area.height - blockH) * 0.45f) + size / 2f
        val first = max(0, cfTarget - 6)
        val last = min(tracks.size - 1, cfTarget + 6)

        class Item(val i: Int, val d: Float, val b: LayoutBounds)
        val items = (first..last).map { i ->
            val d = i - cfPos
            val ad = abs(d)
            val sign = if (d < 0) -1f else 1f
            val offset = if (ad < 1f) ad * size * 0.62f else size * 0.62f + (ad - 1f) * size * 0.30f
            val scale = 1f - min(ad, 3f) * 0.15f
            val s = size * scale
            Item(i, d, LayoutBounds(cx + sign * offset - s / 2f, cy - s / 2f, s, s))
        }.filter { it.b.right > area.x && it.b.x < area.right }

        // 左右两边：越靠近区域边缘越透明，超出区域的部分裁掉
        val fadeW = area.width * 0.22f
        fun edgeFade(b: LayoutBounds): Float {
            val mid = b.x + b.width / 2f
            val e = (min(mid - area.x, area.right - mid) / fadeW).coerceIn(0f, 1f)
            return e * e * (3f - 2f * e)
        }
        val clip = LayoutBounds(area.x, area.y - 12f, area.width, area.height + 12f)
        ui.beginClip(clip)
        for (item in items.sortedByDescending { abs(it.d) }) {
            val ad = abs(item.d)
            val a = (1f - min(ad, 4f) * 0.2f).coerceAtLeast(0.15f) * edgeFade(item.b)
            if (a < 0.01f) continue
            ui.ctx.pushOpacity(a)
            ui.drawCover(item.b, CoverCache.track(tracks[item.i]), 12f)
            if (ad > 0.5f) ui.card(item.b, Color(0f, 0f, 0f, min(0.45f, ad * 0.18f)), 2f)
            ui.ctx.popOpacity()
        }
        ui.endClip()
        for (item in items.sortedBy { abs(it.d) }) {
            if (edgeFade(item.b) < 0.2f) continue     // 几乎看不见的就不响应点击
            val i = item.i
            ui.hits += item.b.intersect(clip) to {
                if (i == cfTarget) playFrom(all, shownList[i].first) else cfTarget = i
            }
        }

        val t = tracks[cfTarget]
        val isCur = MusicPlayer.current?.id == t.id
        val ty = cy + size / 2f + 14f
        val name = ui.trim(t.name, area.width - 40f, 16f, Theme.FONT_SEMIBOLD)
        ui.text(name, cx - ui.width(name, 16f, Theme.FONT_SEMIBOLD) / 2f, ty, 16f, if (isCur) RED else Theme.TEXT_PRIMARY, Theme.FONT_SEMIBOLD)
        val artist = ui.trim(t.artists.joinToString(" / "), area.width - 40f, 12f)
        ui.text(artist, cx - ui.width(artist, 12f) / 2f, ty + 21f, 12f, Theme.TEXT_SECONDARY)
        // 第三行：收费类型 · 热度 · 第几首
        val meta = ArrayList<Pair<String, Color>>(3)
        feeTag(t.fee)?.let { meta.add(it to feeColor(t.fee)) }
        if (t.popularity > 0) meta.add("热度 ${t.popularity}" to Theme.TEXT_TERTIARY)
        meta.add("${cfTarget + 1} / ${tracks.size}" to Theme.TEXT_TERTIARY)
        val sep = " · "
        val sepW = ui.width(sep, 11f)
        var totalW = sepW * (meta.size - 1)
        for (m in meta) totalW += ui.width(m.first, 11f)
        var px = cx - totalW / 2f
        for ((k, m) in meta.withIndex()) {
            if (k > 0) {
                ui.text(sep, px, ty + 38f, 11f, Theme.TEXT_TERTIARY)
                px += sepW
            }
            ui.text(m.first, px, ty + 38f, 11f, m.second)
            px += ui.width(m.first, 11f)
        }
    }

    // ---------------------------------------------------------------- 按键

    /** 筛选框有焦点时的按键；返回 true 表示按键被吃掉了 */
    fun filterKeyTyped(typedChar: Char, keyCode: Int): Boolean {
        if (!filterFocused) return false
        val before = filterText
        when {
            keyCode == Keys.ESCAPE -> clearFilter()
            keyCode == Keys.RETURN || keyCode == Keys.NUMPADENTER -> filterFocused = false
            else -> filter.handleKey(typedChar, keyCode)
        }
        // 只有内容真的变了才回到顶部；方向键 / Ctrl+C 不该重置滚动位置
        if (filterText != before) {
            resetScroll()
            resetCoverflow()
        }
        return true
    }

    /**
     * 歌曲列表页的快捷键（在通用快捷键之前处理）：
     *   Ctrl+F 在歌单里筛选，L 定位到正在播放，Home / End / PgUp / PgDn 翻列表
     */
    fun shortcutBefore(keyCode: Int): Boolean {
        if (!tracksPage) return false
        val listView = !ScreenState.coverView
        when {
            ScreenState.page != Page.SEARCH && DangoClient.platform.ctrlDown && keyCode == Keys.F -> filterFocused = true
            keyCode == Keys.L -> locateCurrent()
            listView && keyCode == Keys.HOME -> scroll = 0
            listView && keyCode == Keys.END -> scroll = Int.MAX_VALUE / 2
            listView && keyCode == Keys.PRIOR -> scroll -= listRows
            listView && keyCode == Keys.NEXT -> scroll += listRows
            else -> return false
        }
        return true
    }

    /** 封面墙：←→ 切换，回车播放（在空格 / 退格之后、←→ 快进快退之前处理） */
    fun coverflowKey(keyCode: Int): Boolean {
        if (!tracksPage || !ScreenState.coverView) return false
        when (keyCode) {
            Keys.RIGHT -> cfTarget++
            Keys.LEFT -> cfTarget--
            Keys.RETURN, Keys.NUMPADENTER -> {
                val all = currentTracks().second
                if (all != null) {
                    val list = shown(all)
                    if (cfTarget in list.indices) playFrom(all, list[cfTarget].first)
                }
            }
            else -> return false
        }
        return true
    }
}

/** 会员金色 */
private val MEMBER_GOLD = Color.fromHex("#FFB340")

/** 收费类型 → 标签；未知（-1）返回 null，不显示 */
private fun feeTag(fee: Int): String? = when (fee) {
    0 -> "免费"
    1 -> "VIP"
    4 -> "付费"
    8 -> "会员音质"
    else -> null
}

/** 收费类型 → 标签颜色：免费绿、VIP / 付费金、会员音质蓝 */
private fun feeColor(fee: Int): Color = when (fee) {
    0 -> Theme.GREEN
    1, 4 -> MEMBER_GOLD
    8 -> Theme.ACCENT
    else -> Theme.TEXT_TERTIARY
}
